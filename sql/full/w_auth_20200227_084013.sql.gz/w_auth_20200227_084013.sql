-- MySQL dump 10.13  Distrib 5.6.44, for Linux (x86_64)
--
-- Host: localhost    Database: w_auth
-- ------------------------------------------------------
-- Server version	5.6.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `sha_pass_hash` varchar(40) NOT NULL DEFAULT '',
  `sessionkey` varchar(80) NOT NULL DEFAULT '',
  `v` varchar(64) NOT NULL DEFAULT '',
  `s` varchar(64) NOT NULL DEFAULT '',
  `token_key` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(254) NOT NULL DEFAULT '',
  `reg_mail` varchar(254) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` int(10) unsigned NOT NULL DEFAULT '0',
  `lock_country` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '4',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `mutereason` varchar(3) NOT NULL DEFAULT '',
  `muteby` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='Account System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'EMO','F485C6118476B0811162CBB503E99979282C736C','E8624C8F1B425A88F0546536185F216372B01F3A01776099671DB28A7B619AF9719A80E16A269CB8','89200B923311EB8CE183786CBC8C86B9E414CB1483A84417287092B8B92A2354','8D5D947B02038202A3B63C1A7E4B7B6E1A446CD14886361233FD2D6EC9FD2A75','','','','2017-08-19 12:14:23','171.88.52.6',0,0,0,'2020-02-07 08:21:10',0,4,0,4,'Win','','',0),(2,'ADMIN','0C08D4CF35CFDA6CDFB9118201E69841B7A9B55E','0492C536884B0568A757ACE4AB54252195163D13E25FB210234BAEAD7FA876CEE687BF16E16B5117','23C7A41456CA29452A5300ECEA8495ED0A3A4A55BF3A7B94D196E97FE994008F','AE9857246CCF8437EE6DBF099863ED46E3630810B3A6949A443FDF60B4B9BC2F','','','','2018-11-06 16:21:47','171.88.52.6',0,0,0,'2020-02-07 17:07:04',0,4,0,4,'Win','','',0),(3,'coolzoom','0190861c1e590ae0b26c02f68e806238558acf20','DAEBE39FB9E8F837A3376A3E741D2814425AA6B3A9D77C9A4BC89B93F77D8A9561D85D01EF382007','51BB748784C9202436499281C2A621610BAC130BD74A8469B80665E91C513A9A','ACF29B8B7193A572530466505E3E449FDA3DF14E5B4825DD9D2D4EC819B5847F','','coolzoom@163.com','','2020-02-03 07:31:25','171.88.52.6',0,0,0,'2020-02-24 12:25:39',0,4,0,4,'Win','','',0),(4,'1qwe01','ed586f4b72859ac40fedb81ae870b6c80e93ff40','BFA58184C4A3AEA821C205E1882BD6B6DB7E784EBB2C644F679E633D5120A79A0C4D4CE757F4849D','45CDBBF6A6877539971897D48C0809072544D13DA84052D7BA5F6906CDF21394','8C486B64337D18D423D4002D24EDECDCE055B95EB6864C3FA1394C43B5897C99','','36933523@qq.com','','2020-02-07 11:06:39','114.102.95.69',0,0,0,'2020-02-26 03:27:51',0,4,0,4,'Win','','',0),(5,'1qwe00','92b88e4586dead3a0ad1caf21bdb1df50ad27ca2','52282F2CE8FA358733FBC9D73B1DD35C83CD4576DE3CE0CB4492D3640FD8989BE8CEE33CBF99E108','214CC02E4B66501A86BD88D7EBB66D61F6F496B1A1E743EC54BB0C8EE8FB81CE','81E28156DADBBAA002053FB5B33A6C0F7E753E2082A90F18A057E763DB4C0B33','','36933526@qq.com','','2020-02-07 11:06:56','114.102.95.69',0,0,0,'2020-02-26 12:23:16',0,4,0,4,'Win','','',0),(6,'123123','149fd192e66f533aa6b338bc1f1750938f15ff1f','03ABBBDC7C6819AA346E35A0BE062C269A37A90FCBBF7B994055A295D5FA901F6F1BE657389976A5','806A920C08A52C349340A6646A284B7E321A12B6464E626EE582349B3C91C0CC','B1798501F9857E6AB26BD2D1902EDBCB2C4785790919694A42F98FA64BAE8795','','251704323@qq.com','','2020-02-07 12:37:57','123.53.191.85',0,0,0,'2020-02-16 03:20:58',0,4,0,4,'Win','','',0),(7,'a00001','b2442599bb386ccfd07e8e187ef7d321179700b0','FC8C515449FDC3EE3214E6AE148832AB05C6B040700787B44DDFC763ABAC4DB92EE91217F7C7C4EE','0B1814FB4B7E4E6F8718BD18E648F9D3E885E330700BE6091386426BBB1668DF','BB8D654ADCAA300F4E916E230E724700AC02392979CFCB3399EEE8DA66E4551B','','as@acc.cc','','2020-02-08 03:20:38','36.152.66.162',0,0,0,'2020-02-25 05:42:12',0,4,0,4,'Win','','',0),(8,'penxxen','ee868e3100a5342c35c113764c6d088202b25c02','E07BC88E677BA890F8B7FBE0B57FBBDA1A2B807281614C076307D1631FA23997775C2FCB3B0F6802','3CFEAB7D274D52DDBA42F1E27FF33023276799905BF28C2A58B9FBE80CE7810C','DADECC50372007E1EB12B5C69B68A4E2DA4FF3631CFC82E568E0DD4D303A4625','','liyongwei18@qq.com','','2020-02-08 05:35:35','124.89.111.173',0,0,0,'2020-02-26 13:37:19',0,4,0,4,'Win','','',0),(9,'lttl','a2d27e31f5473dae6d1fc698cc289053a6ec4a93','B32AD0B93697DFDDDAE89A1AC6C3F16797D6ECDEC846C0ADF3F1F99277359E77B1D396EABE247C82','4A4128B883DE03A71AD3E191B59DA87D3478106BA7D9ADC129220079DF1E8F6B','B9E85D7BCA984B503DAF73750F7229865F1DD78602EBA54B3510F4DC26E535C9','','15181856@qq.com','','2020-02-08 07:24:55','125.65.228.33',0,0,0,'2020-02-26 13:32:55',0,4,0,4,'Win','','',0),(10,'321321','93cd2738da623ac56e3b8877753ac874ee68f570','375178528E424EE3AC867539C5AC5CD7F9ACA706DBD09DA446057EBB1E3A467BD5E1BD150B58E67A','1757B9B532F9454509C935C62C3CA3F84865F59A01F993F5504BAF37092671EF','8178A08053BC8F70A501A19F73899C2C44220B6374CCE75CF63885996583A7A3','','12312313@qq.com','','2020-02-09 05:48:38','1.196.171.129',0,0,0,'2020-02-09 05:49:31',0,4,0,4,'Win','','',0),(11,'a00002','010d42c27ce797dc9eedebff750dfc4291b06344','4DF5DC43E73BF60C0EF760CE6BF2988796CD6612B787D370FE2968BF5C2696F700A1CE8966CB6412','024C995D5658F29413C6FF3A65BC121826E419376DB53EF9F311432DBD467E80','B90CD9B6100BF6CC649B63CDE98426B9BF632B16D94A9D145AD7EE7F84350235','','ss@qq.cc','','2020-02-10 08:17:55','36.152.66.162',0,0,0,'2020-02-25 06:03:43',0,4,0,4,'Win','','',0),(12,'a00003','939d08f3dcd3ca1dd0eecbacf8bcf3a8cf175d4e','99F00BD140963F92D3CDC4F74C65B31B75AC7677334C846BAD5226EE08A7E4914F223DF585B6DFCB','4E6543550485F3A2F063730CB00C5B25E0ED3976783812EE96F2CF602C046514','DF698DE63FECDDA5FB0155B8B6E059F40683D1E4B85779B9DEED7DB520820D5B','','a003@qq.cc','','2020-02-10 08:18:18','36.152.66.162',0,0,0,'2020-02-25 07:27:51',0,4,0,4,'Win','','',0),(13,'1152885','fa0241e60d1b1770385acbb008ea7040f6819111','','','','','734074457@qq.com','','2020-02-10 17:36:13','127.0.0.1',0,0,0,'0000-00-00 00:00:00',0,4,0,0,'','','',0),(14,'l01','b4480b4b677f34db0ad061f37b86f2cf7fbe3756','AFAAF283BDB36433C3694519382E5DBE5031EEC5BA4C6BF2DD5A6E08024FEDE834BE952675E53A4B','59C19C48655C574C9613908D2CD272F6641E01418158883CE7C92422BB3AD2EA','9857AED158CB1C5374F9CAA3916A33AC0C534A91E2589B982A5696A897865FB5','','272935781@qq.com','','2020-02-10 18:33:05','183.150.250.91',0,0,0,'2020-02-21 11:47:56',0,4,0,4,'Win','','',0),(15,'l02','85c45d988d054153098e64f69e4d46924e81370d','3673119DC8193A01DB7BA9EDA25386E93DBC52C36037F189C3A75DB7E41EE8A535AFC55E72F56EAB','28D9442BA037CC2F62359D7E3129BED7F090476B7B3298B27E970ED876A59D97','C80A9379C104A9F96B180052F7D1FD9F6F40F308B70AB1A7234CD5659AB39583','','jjjpoice@qq.com','','2020-02-11 06:59:09','183.150.236.66',0,0,0,'2020-02-18 14:03:10',0,4,0,4,'Win','','',0),(16,'l03','b8f17e44212f1883bbef7be0b9caa2efcb890269','F2048B0A8AD44806AD677A094432D72757A778CD044DB7E85D22758855D57E15058F617DDC40744D','82481C33A70B1F707200FA36EE99B0A8B6672528BD922E35A77C882940CB28A7','9BA62FBF5121C2FCBFBBCE59BA803942C1CED68900D7B1230BA2CCCE10420703','','jjjpoice@163.com','','2020-02-11 07:17:07','183.150.250.91',0,0,0,'2020-02-21 02:10:18',0,4,0,4,'Win','','',0),(17,'wanglin','477f4f6e0798f1b1774720bdc1178291755db461','B4FDF953B47BE858EEFC618A99F0E9AAD7DB2E6E76484EC3B29BB5B72E52423CEAE2E0E951A251E2','3409E853FF233CBD7F0ECABDF0211C655ED1EEB40349582DB0AC2DA4D69631FE','E18EFD63E6ADAEE42CB7C085A15367948E27BEBEBA86D9F20DB88BBE03411FD3','','111111@163.com','','2020-02-14 09:38:15','1.83.34.159',0,0,0,'2020-02-24 00:57:35',0,4,0,4,'Win','','',0),(18,'lttl1','001a02fdcf1cb763d97d5f481b30a6ebf43755bb','D2344BD7964B50E7163AF3757DAC8F34139EF1C248F0A43BF0CA286AF6AAAE440CE322A85B96B549','6E96462A9DA09C6D664F814F5AB44366E41A600C6506310051D686ABAAACC023','D432A24B3E1D3AB1C2BFB844C71E6001DCBDBAABC27C2B47EDB07415C289F3A3','','11785664@qq.om','','2020-02-18 05:36:40','125.65.228.33',0,0,0,'2020-02-26 13:51:38',0,4,0,4,'Win','','',0),(19,'penxxen1','db053c1888a9bf927b1d522da0f03a4f7933e7aa','BDED58E10AED9F8D0942DF56E5383B005904043E8AFD3068D30BB52562E3540EADA49693DD608A76','17622F8C6C50FCD076F870F3CFA46563B7BE0175998513C6FA387B05C57063E9','C6CDD09822B309E750B71E93C984B70FA0667485A788FD4BFF85261F8F748175','','174465446@qq.com','','2020-02-18 11:47:22','124.89.111.173',0,0,0,'2020-02-26 14:29:17',0,4,0,4,'Win','','',0),(20,'a00004','d2e35bd5b0aa301957392a31af9c87d1670d25fb','9F0C210EBDEFFE5593892A22F15F6DDB042C8C0EF5F344F4DEA52B44A392A2B0D606C49198A1186F','1273762E5415A624A1C5ED88F81A75F4E86F769089488AE59046EAB634273F3E','D9285196EB8F7CDEA1EC89BB7CF523EA608E24286B8566851343805F645FD8F7','','19451938@qq.com','','2020-02-20 11:49:28','36.152.66.162',0,0,0,'2020-02-25 05:53:47',0,4,0,4,'Win','','',0),(21,'l04','d661b8fd6d83d83e7e1480c8a2c5162d4f2e8e05','','','','','jjj272935781@163.com','','2020-02-21 14:51:58','127.0.0.1',0,0,0,'0000-00-00 00:00:00',0,4,0,0,'','','',0),(22,'a00005','d23ed13a91d18074f3dc7f24f197a594ceb1a29b','B87BCDDA965CCA60131C808C72C3AE390431CCBF601F1EC457FBBE24182E1D1D2FF62583C9D6CDF3','0DD4E7E59B92D5C4E2114AA3FC4AF00DB3F97839322DBE9A9C92C333FA714D0B','F2F77013E90A3BA63D0224684365C94D71E13E3E85FD9867B3483C7C7200CF1B','','a00005@qq.com','','2020-02-23 11:25:19','117.136.66.133',0,0,0,'2020-02-24 03:26:20',0,4,0,4,'Win','','',0);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_access`
--

DROP TABLE IF EXISTS `account_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  `comment` text,
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_access`
--

LOCK TABLES `account_access` WRITE;
/*!40000 ALTER TABLE `account_access` DISABLE KEYS */;
INSERT INTO `account_access` VALUES (1,255,-1,NULL),(2,6,-1,NULL),(3,255,-1,NULL);
/*!40000 ALTER TABLE `account_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_banned`
--

DROP TABLE IF EXISTS `account_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_banned`
--

LOCK TABLES `account_banned` WRITE;
/*!40000 ALTER TABLE `account_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_log_ip`
--

DROP TABLE IF EXISTS `account_log_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_log_ip` (
  `accountid` int(11) unsigned NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '0.0.0.0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`accountid`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_log_ip`
--

LOCK TABLES `account_log_ip` WRITE;
/*!40000 ALTER TABLE `account_log_ip` DISABLE KEYS */;
INSERT INTO `account_log_ip` VALUES (1,'192.168.1.1','2017-08-19 15:16:31'),(2,'127.0.0.1','2018-11-07 00:22:30'),(2,'192.168.0.7','2020-01-24 00:24:22'),(2,'171.88.52.6','2020-02-03 16:08:56'),(3,'171.88.52.6','2020-02-07 15:48:51'),(1,'171.88.52.6','2020-02-07 16:20:41'),(6,'1.196.171.129','2020-02-07 20:38:54'),(4,'114.99.79.228','2020-02-07 23:35:45'),(7,'153.3.64.17','2020-02-08 11:22:22'),(8,'113.201.100.201','2020-02-08 13:39:53'),(5,'114.99.79.228','2020-02-08 14:51:26'),(9,'182.135.116.62','2020-02-08 18:05:00'),(4,'183.164.102.138','2020-02-09 12:12:34'),(10,'1.196.171.129','2020-02-09 13:49:31'),(5,'183.164.102.138','2020-02-10 11:08:12'),(6,'171.13.243.185','2020-02-10 11:42:21'),(11,'153.3.64.17','2020-02-10 18:47:01'),(12,'153.3.64.17','2020-02-10 18:49:44'),(14,'183.150.239.25','2020-02-11 02:33:33'),(4,'36.59.224.204','2020-02-11 12:02:22'),(5,'36.59.224.204','2020-02-11 14:00:08'),(7,'36.152.66.162','2020-02-11 14:05:09'),(11,'36.152.66.162','2020-02-11 14:08:52'),(15,'183.150.239.25','2020-02-11 14:59:16'),(16,'183.150.239.25','2020-02-11 15:17:28'),(8,'113.201.100.102','2020-02-12 14:48:21'),(8,'113.201.100.161','2020-02-13 13:57:48'),(4,'223.241.135.75','2020-02-13 15:15:06'),(5,'223.241.135.75','2020-02-13 15:54:34'),(14,'183.150.238.51','2020-02-14 02:51:22'),(15,'183.150.238.51','2020-02-14 03:12:49'),(9,'182.135.116.110','2020-02-14 18:49:24'),(4,'114.102.67.89','2020-02-15 12:16:21'),(5,'114.102.67.89','2020-02-15 12:16:40'),(6,'123.53.191.85','2020-02-16 11:20:58'),(16,'183.150.238.51','2020-02-16 13:04:24'),(4,'223.241.135.185','2020-02-17 13:19:44'),(12,'36.152.66.162','2020-02-17 13:44:35'),(8,'113.201.100.251','2020-02-17 13:52:55'),(5,'223.241.135.185','2020-02-17 14:37:11'),(14,'183.150.236.66','2020-02-18 05:20:18'),(16,'183.150.236.66','2020-02-18 05:21:00'),(15,'183.150.236.66','2020-02-18 05:22:10'),(18,'182.135.116.110','2020-02-18 13:42:24'),(19,'113.201.100.251','2020-02-18 19:47:30'),(4,'114.105.255.122','2020-02-19 12:40:55'),(5,'114.105.255.122','2020-02-19 12:44:28'),(8,'113.201.101.251','2020-02-19 14:52:44'),(19,'113.201.101.251','2020-02-19 14:53:10'),(12,'58.240.43.18','2020-02-19 15:48:31'),(7,'58.240.43.18','2020-02-19 15:59:48'),(11,'58.240.43.18','2020-02-19 18:16:14'),(17,'113.135.80.68','2020-02-20 12:21:31'),(9,'171.217.250.134','2020-02-20 19:11:31'),(20,'58.240.43.18','2020-02-20 19:50:53'),(14,'183.150.250.91','2020-02-21 07:36:53'),(16,'183.150.250.91','2020-02-21 07:37:35'),(20,'117.136.45.152','2020-02-21 07:39:00'),(20,'36.152.66.162','2020-02-21 09:30:57'),(5,'114.105.151.184','2020-02-21 15:20:02'),(4,'114.105.151.184','2020-02-21 15:33:17'),(19,'124.89.111.29','2020-02-21 16:23:19'),(8,'124.89.111.29','2020-02-22 12:52:18'),(19,'113.201.101.87','2020-02-23 11:00:57'),(8,'113.201.101.87','2020-02-23 11:01:16'),(4,'114.102.81.226','2020-02-23 11:34:52'),(5,'114.102.81.226','2020-02-23 11:45:51'),(22,'58.240.43.18','2020-02-23 19:25:26'),(18,'171.217.250.134','2020-02-23 19:29:47'),(17,'1.83.34.159','2020-02-24 08:57:35'),(20,'117.136.66.133','2020-02-24 11:24:23'),(12,'117.136.66.133','2020-02-24 11:24:35'),(22,'117.136.66.133','2020-02-24 11:26:20'),(4,'114.102.95.69','2020-02-25 09:34:32'),(7,'117.136.45.69','2020-02-25 09:43:13'),(20,'117.136.45.69','2020-02-25 09:43:23'),(8,'124.89.111.173','2020-02-25 11:38:35'),(19,'124.89.111.173','2020-02-25 11:49:51'),(5,'114.102.95.69','2020-02-25 11:50:42'),(18,'125.65.228.33','2020-02-26 18:02:49'),(9,'125.65.228.33','2020-02-26 19:25:06');
/*!40000 ALTER TABLE `account_log_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_premium`
--

DROP TABLE IF EXISTS `account_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_premium` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT 'Account id',
  `setdate` bigint(40) NOT NULL DEFAULT '0',
  `unsetdate` bigint(40) NOT NULL DEFAULT '0',
  `premium_type` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `gm` varchar(12) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`setdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_premium`
--

LOCK TABLES `account_premium` WRITE;
/*!40000 ALTER TABLE `account_premium` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_rep_mods`
--

DROP TABLE IF EXISTS `account_rep_mods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_rep_mods` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `reputationId` int(10) unsigned NOT NULL DEFAULT '0',
  `modifier` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`reputationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_rep_mods`
--

LOCK TABLES `account_rep_mods` WRITE;
/*!40000 ALTER TABLE `account_rep_mods` DISABLE KEYS */;
INSERT INTO `account_rep_mods` VALUES (7,1337,100),(9,1337,100),(19,1337,100);
/*!40000 ALTER TABLE `account_rep_mods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_spell`
--

DROP TABLE IF EXISTS `account_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_spell` (
  `accountId` int(11) NOT NULL,
  `spell` int(10) NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`accountId`,`spell`),
  KEY `account` (`accountId`) USING HASH,
  KEY `account_spell` (`accountId`,`spell`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_spell`
--

LOCK TABLES `account_spell` WRITE;
/*!40000 ALTER TABLE `account_spell` DISABLE KEYS */;
INSERT INTO `account_spell` VALUES (1,42777,1,0),(1,72286,1,0),(4,17462,1,0),(4,17463,1,0),(4,17464,1,0),(4,17465,1,0),(4,23246,1,0),(4,25953,1,0),(4,26054,1,0),(4,26055,1,0),(4,26056,1,0),(4,32243,1,0),(4,46199,1,0),(4,59571,1,0),(4,59650,1,0),(4,64977,1,0),(4,66846,1,0),(4,88718,1,0),(4,98718,1,0),(4,101542,1,0),(4,123993,1,0),(4,127174,1,0),(4,129932,1,0),(4,129934,1,0),(4,129935,1,0),(4,138424,1,0),(4,138425,1,0),(4,138426,1,0),(4,138643,1,0),(5,32244,1,0),(5,33660,1,0),(5,34795,1,0),(5,35022,1,0),(6,32297,1,0),(6,59571,1,0),(7,23249,1,0),(7,32244,1,0),(7,59571,1,0),(7,59650,1,0),(7,61447,1,0),(7,123993,1,0),(7,127154,1,0),(7,129934,1,0),(7,138641,1,0),(8,23228,1,0),(8,32240,1,0),(8,123993,1,0),(8,129918,1,0),(9,6653,1,0),(9,23251,1,0),(9,32297,1,0),(9,59571,1,0),(9,59650,1,0),(9,61447,1,0),(11,32244,1,0),(11,59571,1,0),(11,138641,1,0),(12,23241,1,0),(12,32244,1,0),(12,32297,1,0),(12,59571,1,0),(12,127286,1,0),(14,23246,1,0),(14,32246,1,0),(15,32243,1,0),(15,32246,1,0),(15,32296,1,0),(15,32297,1,0),(15,34896,1,0),(15,36027,1,0),(15,39317,1,0),(15,39318,1,0),(15,39319,1,0),(15,39800,1,0),(15,39801,1,0),(15,39802,1,0),(15,41513,1,0),(15,41514,1,0),(15,41515,1,0),(15,41516,1,0),(15,41517,1,0),(15,41518,1,0),(15,43927,1,0),(17,32243,1,0),(18,6653,1,0),(18,18989,1,0),(18,23247,1,0),(18,23252,1,0),(18,32297,1,0),(18,59571,1,0),(18,123992,1,0),(19,32245,1,0),(19,59571,1,0),(19,61467,1,0),(19,123886,1,0),(19,138643,1,0),(20,32245,1,0),(20,59571,1,0),(20,87090,1,0),(22,32245,1,0),(22,64977,1,0),(22,66846,1,0);
/*!40000 ALTER TABLE `account_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `firewall_farms`
--

DROP TABLE IF EXISTS `firewall_farms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firewall_farms` (
  `ip` tinytext NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `firewall_farms`
--

LOCK TABLES `firewall_farms` WRITE;
/*!40000 ALTER TABLE `firewall_farms` DISABLE KEYS */;
/*!40000 ALTER TABLE `firewall_farms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_banned`
--

DROP TABLE IF EXISTS `ip_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Banned IPs';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_banned`
--

LOCK TABLES `ip_banned` WRITE;
/*!40000 ALTER TABLE `ip_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_to_country`
--

DROP TABLE IF EXISTS `ip_to_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_to_country` (
  `IP_FROM` double NOT NULL,
  `IP_TO` double NOT NULL,
  `COUNTRY_CODE` char(2) DEFAULT NULL,
  `COUNTRY_CODE_3` char(3) NOT NULL,
  `COUNTRY_NAME` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IP_FROM`,`IP_TO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_to_country`
--

LOCK TABLES `ip_to_country` WRITE;
/*!40000 ALTER TABLE `ip_to_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_to_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_vote`
--

DROP TABLE IF EXISTS `log_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_vote` (
  `top_name` varchar(15) NOT NULL DEFAULT 'top',
  `ip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `date` int(11) NOT NULL,
  PRIMARY KEY (`top_name`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_vote`
--

LOCK TABLES `log_vote` WRITE;
/*!40000 ALTER TABLE `log_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `time` int(10) unsigned NOT NULL,
  `realm` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `string` text CHARACTER SET latin1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mails`
--

DROP TABLE IF EXISTS `mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mails` (
  `email` varchar(254) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mails`
--

LOCK TABLES `mails` WRITE;
/*!40000 ALTER TABLE `mails` DISABLE KEYS */;
/*!40000 ALTER TABLE `mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realmcharacters`
--

DROP TABLE IF EXISTS `realmcharacters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Realm Character Tracker';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realmcharacters`
--

LOCK TABLES `realmcharacters` WRITE;
/*!40000 ALTER TABLE `realmcharacters` DISABLE KEYS */;
INSERT INTO `realmcharacters` VALUES (1,1,1),(1,2,6),(1,3,7),(1,4,2),(1,5,6),(1,6,9),(1,7,2),(1,8,4),(1,9,2),(1,10,4),(1,11,2),(1,12,2),(1,14,2),(1,15,1),(1,16,1),(1,17,3),(1,18,2),(1,19,2),(1,20,1),(1,22,1);
/*!40000 ALTER TABLE `realmcharacters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realmlist`
--

DROP TABLE IF EXISTS `realmlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float unsigned NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '16135',
  `online` int(10) DEFAULT '0',
  `delay` int(10) unsigned NOT NULL DEFAULT '0',
  `queued` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Realm System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realmlist`
--

LOCK TABLES `realmlist` WRITE;
/*!40000 ALTER TABLE `realmlist` DISABLE KEYS */;
INSERT INTO `realmlist` VALUES (1,'熊猫酒仙','39.105.210.193',8085,0,0,1,0,0,18019,1,10,0);
/*!40000 ALTER TABLE `realmlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transferts`
--

DROP TABLE IF EXISTS `transferts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transferts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` int(11) NOT NULL,
  `perso_guid` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `revision` blob NOT NULL,
  `dump` longtext NOT NULL,
  `last_error` blob NOT NULL,
  `nb_attempt` int(11) NOT NULL,
  `state` int(10) DEFAULT NULL,
  `error` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferts`
--

LOCK TABLES `transferts` WRITE;
/*!40000 ALTER TABLE `transferts` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transferts_logs`
--

DROP TABLE IF EXISTS `transferts_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transferts_logs` (
  `id` int(11) DEFAULT NULL,
  `account` int(11) DEFAULT NULL,
  `perso_guid` int(11) DEFAULT NULL,
  `from` int(2) DEFAULT NULL,
  `to` int(2) DEFAULT NULL,
  `dump` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferts_logs`
--

LOCK TABLES `transferts_logs` WRITE;
/*!40000 ALTER TABLE `transferts_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferts_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uptime`
--

DROP TABLE IF EXISTS `uptime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uptime` (
  `realmid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `uptime` int(10) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'Trinitycore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Uptime system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uptime`
--

LOCK TABLES `uptime` WRITE;
/*!40000 ALTER TABLE `uptime` DISABLE KEYS */;
INSERT INTO `uptime` VALUES (1,1489682470,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1489682874,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503144828,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503144890,600,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503145617,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503147354,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503147627,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503148134,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503148578,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503148963,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503150532,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503150888,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503151003,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503151116,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503151305,600,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503152423,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503152987,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503154862,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1503155377,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541521279,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541521449,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541729951,1807,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541731902,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541732570,601,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541733345,650,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541734058,601,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541734849,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Release)'),(1,1541830937,10243,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541858642,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541859452,2401,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541863163,1201,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541864623,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541865253,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541906340,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541906607,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541906769,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1541907085,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541907457,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541907806,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541908176,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541908771,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541909195,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1541917814,1858,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1553586348,1814,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1553588595,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1579790738,6007,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1579797409,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1579797560,1801,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1579798092,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580140493,608,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580143054,602,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, Debug)'),(1,1580144135,3000,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580307719,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580308304,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580308422,1200,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580310216,0,0,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580310586,1800,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580312939,2400,1,'JadeCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Win64, RelWithDebInfo)'),(1,1580713031,1803,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580715238,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580715379,1200,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580716805,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580716847,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580716953,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580717076,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580717135,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580717191,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580717616,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580718029,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580718086,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580718266,1201,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580719931,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580742179,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580743282,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580744791,604,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580745997,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580803447,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580803741,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580804511,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580804762,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580806352,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580806635,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580806793,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580806866,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580807323,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580807675,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580828117,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1580835192,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581006821,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581007156,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581047288,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581059629,3600,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581063749,1200,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581065470,2401,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068447,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068463,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068480,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068497,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068513,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068529,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068546,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068562,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068579,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068595,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068612,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068628,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068644,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068661,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068677,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068694,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068710,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068727,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068743,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068760,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068776,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068793,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068816,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068833,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068849,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068866,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068883,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068900,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068916,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068944,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068961,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068977,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581068994,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069010,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069027,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069043,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069060,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069076,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069093,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069109,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069126,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069142,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069159,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069175,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069192,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069208,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069225,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069242,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069258,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069275,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069291,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069308,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069325,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069341,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069358,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069374,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069391,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069407,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069424,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069440,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069457,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069473,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069490,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069507,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069523,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069540,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069556,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069573,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069589,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069606,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069622,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069639,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069655,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069672,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069689,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069705,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069722,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069738,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069755,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069771,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069788,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069805,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069821,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069838,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069854,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069871,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069887,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069904,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069921,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069937,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069954,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069970,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581069987,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070003,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070020,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070037,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070053,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070070,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070086,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070104,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070120,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070137,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070153,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070170,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070186,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070203,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070220,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581070236,1200,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581071746,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581071775,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581072134,600,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581072884,18600,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581092075,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581092209,1800,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581094399,600,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581095168,10200,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581105735,34800,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581140697,4200,6,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145414,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145446,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145462,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145540,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145569,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145585,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145608,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145673,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145795,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581145821,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581146222,601,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581147142,1200,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581148574,3000,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581151932,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581152109,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581152182,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581152255,1200,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581153981,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154159,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154225,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154486,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154534,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154804,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581154888,1202,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581156642,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581156681,3001,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581159753,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581159968,4201,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581164579,17400,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581182115,9601,1,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581192135,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581278535,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581364936,37801,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581402952,1801,3,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405356,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405372,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405389,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405405,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405421,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405438,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405454,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405471,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405487,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405504,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405520,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405536,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405553,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405569,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405585,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405602,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405626,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405658,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405682,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405704,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405723,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405739,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405756,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405772,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405789,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405805,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405821,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405838,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405870,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405896,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405917,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405933,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405950,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405967,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581405985,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406007,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406024,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406040,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406057,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406073,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406090,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406106,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406122,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406138,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406155,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406171,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406187,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406204,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406220,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406236,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406253,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406270,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406287,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406304,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406320,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406337,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406354,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406716,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581406821,44400,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581451336,45000,2,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581496855,40800,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581537735,85800,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581624135,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581710535,75001,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581819322,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581819457,39000,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581859018,24000,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581915795,53400,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1581969737,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582056135,85800,6,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582142535,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582228936,85800,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582315336,85800,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582401735,85800,6,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582488135,57600,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582546063,28200,8,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582574534,19200,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582593905,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582593935,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582593980,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582594010,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582594083,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582594546,0,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582594926,65400,5,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582660935,85800,4,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)'),(1,1582747339,16200,0,'UwowCore rev. 0000-00-00 00:00:00 +0000 (Archived) (Unix)');
/*!40000 ALTER TABLE `uptime` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-27  8:40:13
